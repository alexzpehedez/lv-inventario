/* ===================================================
   MENU LATERAL ☰
=================================================== */

// Espera que cargue todo
document.addEventListener("DOMContentLoaded", () => {

    crearMenuLateral();

    activarMenu();

});

/* ===================================================
   CREAR MENU
=================================================== */

function crearMenuLateral(){

    // Crear fondo oscuro
    let overlay = document.createElement("div");
    overlay.className = "menu-overlay";

    // Crear menu
    let sidebar = document.createElement("div");
    sidebar.className = "sidebar-menu";

    sidebar.innerHTML = `

        <div class="sidebar-header">

            <h2>LOUIS VUITTON</h2>

            <button id="cerrarMenu">✕</button>

        </div>

        <div class="sidebar-links">

            <a href="panel.html">
                Panel
            </a>

            <a href="producto.html">
                Nuevo Producto
            </a>

            <a href="catalogo.html">
                Catálogo
            </a>

            <a href="actinventario.html">
                Inventario
            </a>

        </div>

    `;

    document.body.appendChild(overlay);
    document.body.appendChild(sidebar);

}

/* ===================================================
   ACTIVAR MENU
=================================================== */

function activarMenu(){

    let menuBtn = document.querySelector(".menu-icon");

    let sidebar = document.querySelector(".sidebar-menu");

    let overlay = document.querySelector(".menu-overlay");

    // Abrir menu
    if(menuBtn){

        menuBtn.addEventListener("click", () => {

            sidebar.classList.add("active");

            overlay.classList.add("active");

        });

    }

    // Cerrar menu
    document.addEventListener("click", (e) => {

        if(e.target.id === "cerrarMenu"){

            sidebar.classList.remove("active");

            overlay.classList.remove("active");

        }

    });

    // Cerrar al tocar fondo
    overlay.addEventListener("click", () => {

        sidebar.classList.remove("active");

        overlay.classList.remove("active");

    });

}

/* ===================================================
   BASE PARA MONGODB CLOUD
=================================================== */

/*
    Estas funciones son base para conectar
    frontend con backend y MongoDB Atlas
*/

/* ===================================================
   URL BASE
=================================================== */

const API_URL = "http://localhost:3000";

/* ===================================================
   OBTENER PRODUCTOS
=================================================== */

async function obtenerProductos(){

    try{

        let res = await fetch(`${API_URL}/productos`);

        let data = await res.json();

        console.log("Productos:", data);

        return data;

    }catch(error){

        console.error("Error obteniendo productos", error);

    }

}

/* ===================================================
   OBTENER PRODUCTO POR ID
=================================================== */

async function obtenerProducto(id){

    try{

        let res = await fetch(`${API_URL}/productos/${id}`);

        let data = await res.json();

        return data;

    }catch(error){

        console.error(error);

    }

}

/* ===================================================
   ACTUALIZAR STOCK
=================================================== */

async function actualizarStock(id, cantidad){

    try{

        let res = await fetch(`${API_URL}/productos/${id}`, {

            method: "PUT",

            headers:{
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                cantidad: cantidad
            })

        });

        let data = await res.json();

        console.log(data);

    }catch(error){

        console.error(error);

    }

}

/* ===================================================
   ELIMINAR PRODUCTO
=================================================== */

async function eliminarProducto(id){

    let confirmar = confirm("¿Eliminar producto?");

    if(!confirmar) return;

    try{

        await fetch(`${API_URL}/productos/${id}`, {

            method: "DELETE"

        });

        alert("Producto eliminado");

        location.reload();

    }catch(error){

        console.error(error);

    }

}
 document.addEventListener("DOMContentLoaded", () => {

            /* =========================
               BOTONES +
            ========================= */

            let plusBtns = document.querySelectorAll(".plus-btn");

            plusBtns.forEach(btn => {

                btn.addEventListener("click", () => {

                    let input =
                        btn.parentElement.querySelector(".step-input");

                    input.value =
                        parseInt(input.value) + 1;

                });

            });

            /* =========================
               BOTONES -
            ========================= */

            let minusBtns = document.querySelectorAll(".minus-btn");

            minusBtns.forEach(btn => {

                btn.addEventListener("click", () => {

                    let input =
                        btn.parentElement.querySelector(".step-input");

                    let valor =
                        parseInt(input.value);

                    if(valor > 0){

                        input.value = valor - 1;

                    }

                });

            });

            /* =========================
               RESET FILA
            ========================= */

            let resetBtns =
                document.querySelectorAll(".reset-row-btn");

            resetBtns.forEach(btn => {

                btn.addEventListener("click", () => {

                    let fila = btn.closest("tr");

                    let stockActual =
                        fila.querySelector(".stock-pill")
                        .textContent
                        .replace("UNID.", "")
                        .trim();

                    fila.querySelector(".step-input").value =
                        stockActual;

                });

            });

        });
        function abrirProducto(){

  window.location.href = "entrar-producto.html";

}

/* =========================
   BUSCADOR CATALOGO
========================= */

document.addEventListener("DOMContentLoaded", () => {

  let search = document.querySelector(".search-input");

  if (search) {

    search.addEventListener("keyup", () => {

      let filtro = search.value.toLowerCase();

      let productos =
        document.querySelectorAll(".producto-card");

      productos.forEach(p => {

        let nombre =
          p.querySelector("h3")
           .textContent
           .toLowerCase();

        p.style.display =
          nombre.includes(filtro)
          ? "block"
          : "none";

      });

    });

  }

});